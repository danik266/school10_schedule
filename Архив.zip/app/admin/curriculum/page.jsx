"use client";
import { useState, useEffect } from "react";
import {
  BarChart2,
  BookOpen,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
} from "lucide-react";

function StatusBadge({ percent }) {
  if (percent >= 100)
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
        <CheckCircle size={12} /> Выполнено
      </span>
    );
  if (percent >= 70)
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">
        <TrendingUp size={12} /> В норме
      </span>
    );
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">
      <AlertTriangle size={12} /> Отставание
    </span>
  );
}

// Число учебных недель в году (стандарт РФ)
const WEEKS_IN_YEAR = 34;

export default function CurriculumPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("plan");

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      // 1. Загружаем все классы
      const classesData = await fetch("/api/classes").then((r) => r.json());
      const allClasses = [
        ...(classesData.small || []),
        ...(classesData.large || []),
      ];

      // 2. Загружаем полное расписание (с joined данными)
      const scheduleRaw = await fetch("/api/get-schedule").then((r) => r.json());
      const schedule = scheduleRaw.schedule || [];

      // 3. Для каждого класса — загружаем предметы (учебный план)
      const subjectsByClass = await Promise.all(
        allClasses.map((cls) =>
          fetch(`/api/subjects/${cls.class_id}`)
            .then((r) => r.json())
            .then((subjects) => ({ cls, subjects }))
        )
      );

      // 4. Считаем фактические часы из расписания
      // schedule entry содержит weekData (monday, tuesday, ... friday) — часов в неделю
      // Итого за год = hours_per_week * WEEKS_IN_YEAR
      // Но фактически проведённые часы нам неизвестны напрямую.
      // Считаем: conductedHours = сумма часов из weekData для данного предмета+класса
      // (hours_per_week * WEEKS_IN_YEAR — это план; факт берём из расписания как часы в неделю)
      
      // Сначала строим map: class_id + subject_id -> часов в неделю (из расписания)
      const scheduleMap = {};
      schedule.forEach((s) => {
        const key = `${s.class_id}_${s.subject_id}`;
        const weekHours =
          (Number(s.monday) || 0) +
          (Number(s.tuesday) || 0) +
          (Number(s.wednesday) || 0) +
          (Number(s.thursday) || 0) +
          (Number(s.friday) || 0);
        scheduleMap[key] = (scheduleMap[key] || 0) + weekHours;
      });

      // 5. Строим строки таблицы
      const result = [];
      for (const { cls, subjects } of subjectsByClass) {
        for (const subj of subjects) {
          const plannedHoursPerWeek = Number(subj.hours_per_week) || 0;
          const plannedHoursYear = plannedHoursPerWeek * WEEKS_IN_YEAR;
          const key = `${cls.class_id}_${subj.subject_id}`;
          const scheduledHoursPerWeek = scheduleMap[key] || 0;
          const scheduledHoursYear = scheduledHoursPerWeek * WEEKS_IN_YEAR;

          result.push({
            id: key,
            subject: subj.name,
            grade: cls.class_name,
            class_id: cls.class_id,
            subject_id: subj.subject_id,
            plannedPerWeek: plannedHoursPerWeek,
            plannedYear: plannedHoursYear,
            scheduledPerWeek: scheduledHoursPerWeek,
            scheduledYear: scheduledHoursYear,
            inSchedule: !!scheduleMap[key],
          });
        }
      }

      setRows(result);
    } catch (e) {
      console.error(e);
      setError("Ошибка загрузки данных: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Считаем статистику
  const totalPlanned = rows.reduce((s, r) => s + r.plannedYear, 0);
  const totalScheduled = rows.reduce((s, r) => s + r.scheduledYear, 0);
  const overallPercent =
    totalPlanned > 0 ? Math.round((totalScheduled / totalPlanned) * 100) : 0;

  const getPercent = (r) =>
    r.plannedYear > 0 ? Math.round((r.scheduledYear / r.plannedYear) * 100) : 0;

  const behind = rows.filter((r) => getPercent(r) < 70);
  const onTrack = rows.filter((r) => {
    const p = getPercent(r);
    return p >= 70 && p < 100;
  });
  const done = rows.filter((r) => getPercent(r) >= 100);
  const notInSchedule = rows.filter((r) => !r.inSchedule);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-3 text-gray-400">
          <RefreshCw size={32} className="animate-spin" />
          <p>Загрузка данных...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center max-w-md">
          <AlertTriangle size={32} className="text-red-400 mx-auto mb-3" />
          <p className="text-red-600 font-medium">{error}</p>
          <button
            onClick={loadData}
            className="mt-4 px-4 py-2 bg-[#0d254c] text-white rounded-lg text-sm hover:bg-blue-800 transition"
          >
            Повторить
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      {/* Заголовок */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-[#0d254c]">Учебный план</h1>
          <p className="text-gray-500 text-sm mt-1">
            Соответствие расписания учебному плану • {WEEKS_IN_YEAR} учебных недель
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={loadData}
            className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 transition"
          >
            <RefreshCw size={14} /> Обновить
          </button>
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab("plan")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition ${
                activeTab === "plan"
                  ? "bg-[#0d254c] text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <BookOpen size={16} /> Учебный план
            </button>
            <button
              onClick={() => setActiveTab("stats")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition ${
                activeTab === "stats"
                  ? "bg-[#0d254c] text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <BarChart2 size={16} /> Статистика
            </button>
          </div>
        </div>
      </div>

      {/* ===== ВКЛАДКА: УЧЕБНЫЙ ПЛАН ===== */}
      {activeTab === "plan" && (
        <div>
          {notInSchedule.length > 0 && (
            <div className="mb-4 flex items-start gap-3 bg-orange-50 border border-orange-200 rounded-xl p-4">
              <AlertTriangle size={18} className="text-orange-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-orange-700">
                  {notInSchedule.length} предмет(ов) из учебного плана не добавлены в расписание
                </p>
                <p className="text-xs text-orange-500 mt-0.5">
                  Для них часы в расписании равны нулю
                </p>
              </div>
            </div>
          )}

          <div className="overflow-x-auto border border-gray-200 rounded-xl">
            <table className="w-full text-left bg-white">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="p-4 font-semibold text-gray-600 text-sm">Предмет</th>
                  <th className="p-4 font-semibold text-gray-600 text-sm">Класс</th>
                  <th className="p-4 font-semibold text-gray-600 text-sm">Часов/нед (план)</th>
                  <th className="p-4 font-semibold text-gray-600 text-sm">Часов/год (план)</th>
                  <th className="p-4 font-semibold text-gray-600 text-sm">Часов/нед (расп.)</th>
                  <th className="p-4 font-semibold text-gray-600 text-sm">Часов/год (расп.)</th>
                  <th className="p-4 font-semibold text-gray-600 text-sm">Выполнение</th>
                  <th className="p-4 font-semibold text-gray-600 text-sm">Статус</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-gray-400">
                      Данные не найдены
                    </td>
                  </tr>
                ) : (
                  rows.map((row) => {
                    const percent = getPercent(row);
                    return (
                      <tr
                        key={row.id}
                        className={`border-b border-gray-100 hover:bg-gray-50 ${
                          !row.inSchedule ? "bg-orange-50/40" : ""
                        }`}
                      >
                        <td className="p-4 font-medium">{row.subject}</td>
                        <td className="p-4 text-gray-500">{row.grade}</td>
                        <td className="p-4">{row.plannedPerWeek} ч</td>
                        <td className="p-4 font-semibold text-gray-700">{row.plannedYear} ч</td>
                        <td className={`p-4 ${!row.inSchedule ? "text-orange-400" : ""}`}>
                          {row.scheduledPerWeek} ч
                        </td>
                        <td className={`p-4 font-semibold ${!row.inSchedule ? "text-orange-400" : "text-gray-700"}`}>
                          {row.scheduledYear} ч
                        </td>
                        <td className="p-4 min-w-[150px]">
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full transition-all ${
                                  percent >= 100
                                    ? "bg-green-500"
                                    : percent >= 70
                                    ? "bg-yellow-400"
                                    : "bg-red-400"
                                }`}
                                style={{ width: `${Math.min(percent, 100)}%` }}
                              />
                            </div>
                            <span className="text-xs font-semibold text-gray-700 w-10 text-right">
                              {percent}%
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <StatusBadge percent={percent} />
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===== ВКЛАДКА: СТАТИСТИКА ===== */}
      {activeTab === "stats" && (
        <div>
          {/* Сводные карточки */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-[#0d254c] text-white rounded-xl p-5">
              <p className="text-blue-200 text-sm mb-1">Всего по плану</p>
              <p className="text-3xl font-bold">{totalPlanned} ч</p>
              <p className="text-blue-300 text-xs mt-1">за {WEEKS_IN_YEAR} нед.</p>
            </div>
            <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
              <p className="text-gray-500 text-sm mb-1">По расписанию</p>
              <p className="text-3xl font-bold text-gray-800">{totalScheduled} ч</p>
              <p className="text-gray-400 text-xs mt-1">за {WEEKS_IN_YEAR} нед.</p>
            </div>
            <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
              <p className="text-gray-500 text-sm mb-1">Соответствие плану</p>
              <p
                className={`text-3xl font-bold ${
                  overallPercent >= 70 ? "text-green-600" : "text-red-500"
                }`}
              >
                {overallPercent}%
              </p>
            </div>
            <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
              <p className="text-gray-500 text-sm mb-1">Не внесено в расписание</p>
              <p className="text-3xl font-bold text-orange-500">{notInSchedule.length}</p>
              <p className="text-gray-400 text-xs mt-1">предметов</p>
            </div>
          </div>

          {/* Общий прогресс */}
          <div className="bg-white border border-gray-200 rounded-xl p-6 mb-6 shadow-sm">
            <div className="flex justify-between mb-3">
              <h2 className="font-semibold text-gray-700">
                Общее соответствие учебному плану на год
              </h2>
              <span className="font-bold text-lg text-[#0d254c]">{overallPercent}%</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-4">
              <div
                className={`h-4 rounded-full transition-all ${
                  overallPercent >= 100
                    ? "bg-green-500"
                    : overallPercent >= 70
                    ? "bg-yellow-400"
                    : "bg-red-400"
                }`}
                style={{ width: `${Math.min(overallPercent, 100)}%` }}
              />
            </div>
            <div className="flex justify-between mt-2 text-xs text-gray-400">
              <span>0%</span>
              <span className="text-yellow-500 font-medium">70% — допустимый минимум</span>
              <span>100%</span>
            </div>
          </div>

          {/* Три колонки по статусам */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8">
            <div className="bg-red-50 border border-red-200 rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle size={18} className="text-red-500" />
                <h3 className="font-semibold text-red-700">Отставание (&lt;70%)</h3>
                <span className="ml-auto bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  {behind.length}
                </span>
              </div>
              {behind.length === 0 ? (
                <p className="text-sm text-red-400">Нет отставаний</p>
              ) : (
                behind.map((r) => (
                  <div
                    key={r.id}
                    className="flex justify-between text-sm py-1.5 border-b border-red-100 last:border-0"
                  >
                    <span className="text-gray-700">
                      {r.subject}{" "}
                      <span className="text-gray-400">({r.grade})</span>
                    </span>
                    <span className="font-semibold text-red-600">{getPercent(r)}%</span>
                  </div>
                ))
              )}
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp size={18} className="text-yellow-500" />
                <h3 className="font-semibold text-yellow-700">В норме (70–99%)</h3>
                <span className="ml-auto bg-yellow-400 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  {onTrack.length}
                </span>
              </div>
              {onTrack.length === 0 ? (
                <p className="text-sm text-yellow-400">Нет предметов</p>
              ) : (
                onTrack.map((r) => (
                  <div
                    key={r.id}
                    className="flex justify-between text-sm py-1.5 border-b border-yellow-100 last:border-0"
                  >
                    <span className="text-gray-700">
                      {r.subject}{" "}
                      <span className="text-gray-400">({r.grade})</span>
                    </span>
                    <span className="font-semibold text-yellow-600">{getPercent(r)}%</span>
                  </div>
                ))
              )}
            </div>

            <div className="bg-green-50 border border-green-200 rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle size={18} className="text-green-500" />
                <h3 className="font-semibold text-green-700">Выполнено (≥100%)</h3>
                <span className="ml-auto bg-green-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  {done.length}
                </span>
              </div>
              {done.length === 0 ? (
                <p className="text-sm text-green-400">Нет выполненных</p>
              ) : (
                done.map((r) => (
                  <div
                    key={r.id}
                    className="flex justify-between text-sm py-1.5 border-b border-green-100 last:border-0"
                  >
                    <span className="text-gray-700">
                      {r.subject}{" "}
                      <span className="text-gray-400">({r.grade})</span>
                    </span>
                    <span className="font-semibold text-green-600">✓</span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Детальная таблица */}
          <div>
            <h2 className="font-semibold text-gray-700 mb-3">
              Детализация по всем предметам
            </h2>
            <div className="overflow-x-auto border border-gray-200 rounded-xl">
              <table className="w-full text-left bg-white">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="p-4 font-semibold text-gray-600 text-sm">Предмет</th>
                    <th className="p-4 font-semibold text-gray-600 text-sm">Класс</th>
                    <th className="p-4 font-semibold text-gray-600 text-sm">План (год)</th>
                    <th className="p-4 font-semibold text-gray-600 text-sm">Расписание (год)</th>
                    <th className="p-4 font-semibold text-gray-600 text-sm">Разница</th>
                    <th className="p-4 font-semibold text-gray-600 text-sm">Выполнение</th>
                    <th className="p-4 font-semibold text-gray-600 text-sm">Статус</th>
                  </tr>
                </thead>
                <tbody>
                  {rows
                    .slice()
                    .sort((a, b) => getPercent(a) - getPercent(b))
                    .map((row) => {
                      const percent = getPercent(row);
                      const diff = row.scheduledYear - row.plannedYear;
                      return (
                        <tr
                          key={row.id}
                          className="border-b border-gray-100 hover:bg-gray-50"
                        >
                          <td className="p-4 font-medium">{row.subject}</td>
                          <td className="p-4 text-gray-500">{row.grade}</td>
                          <td className="p-4">{row.plannedYear} ч</td>
                          <td className="p-4">{row.scheduledYear} ч</td>
                          <td
                            className={`p-4 font-medium ${
                              diff >= 0 ? "text-green-600" : "text-red-500"
                            }`}
                          >
                            {diff >= 0 ? `+${diff}` : diff} ч
                          </td>
                          <td className="p-4 min-w-[150px]">
                            <div className="flex items-center gap-2">
                              <div className="flex-1 bg-gray-200 rounded-full h-2">
                                <div
                                  className={`h-2 rounded-full ${
                                    percent >= 100
                                      ? "bg-green-500"
                                      : percent >= 70
                                      ? "bg-yellow-400"
                                      : "bg-red-400"
                                  }`}
                                  style={{ width: `${Math.min(percent, 100)}%` }}
                                />
                              </div>
                              <span className="text-xs font-semibold w-10 text-right">
                                {percent}%
                              </span>
                            </div>
                          </td>
                          <td className="p-4">
                            <StatusBadge percent={percent} />
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
                <tfoot className="bg-gray-50 border-t-2 border-gray-300">
                  <tr>
                    <td className="p-4 font-bold text-gray-700" colSpan={2}>
                      Итого
                    </td>
                    <td className="p-4 font-bold">{totalPlanned} ч</td>
                    <td className="p-4 font-bold">{totalScheduled} ч</td>
                    <td
                      className={`p-4 font-bold ${
                        totalScheduled - totalPlanned >= 0
                          ? "text-green-600"
                          : "text-red-500"
                      }`}
                    >
                      {totalScheduled - totalPlanned >= 0 ? "+" : ""}
                      {totalScheduled - totalPlanned} ч
                    </td>
                    <td className="p-4 font-bold" colSpan={2}>
                      <span
                        className={`text-lg ${
                          overallPercent >= 70 ? "text-green-600" : "text-red-500"
                        }`}
                      >
                        {overallPercent}%
                      </span>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}